#!/bin/bash
# average words per line in file

#sets the variables
words=$(cat myfile.txt| wc -w)
lines=$(cat myfile.txt| wc -l)

#pipe into bc calc and create average.
avg=$(echo "scale=3; $words / $lines" | bc)

#print the results
echo "The average words per line of myfile.txt is $avg"
