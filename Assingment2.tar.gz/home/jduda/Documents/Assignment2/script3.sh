#!/bin/bash
# check to see if it is the 31st day of the month

#checks and sets the date
date=`date +%d`

#checks if it is the 31st of the month
if [ $date -eq 31 ]
then
    if [ -d /home/$USER/Backup ]
    then
	echo "Starting backup."
    else
	#creates a directory Backup if it does not already exist
	cd /home/$USER/
	mkdir Backup
	echo "starting backup"
    fi
    #tars and gzips Downloads folder to Backup
    cd /home/$USER/Backup
    tar -czvf backup.tar.gz /home/$USER/Downloads
    echo "Backup complete."
else
    echo "Nothing executed not the 31st day of the month"
fi

	
