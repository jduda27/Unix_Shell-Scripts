#!/bin/bash
# Display size of user's home directory and the date and store to homesize.log

#set variables
date=$(date)
size=$(du -hs /home/$USER)

#append or create a log homesize.log
echo "$date $size" >> homesize.log
